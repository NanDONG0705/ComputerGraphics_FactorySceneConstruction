#pragma once

#include <GLFW/glfw3.h>
#include "camera.h"
#include "model.h"

// window's size
int WindowWidth = 1500;
int WindowHeight = 1000;

// camera
Camera camera(glm::vec3(0.0f, 4.0f, 20.0f));
float lastX = WindowWidth / 2.0f;
float lastY = WindowHeight / 2.0f;
bool firstMouse = true;

bool isOpenLight = true;

void framebuffer_size_callback(GLFWwindow* window, int w, int h)
{
	WindowWidth = w;
	WindowHeight = h;
	glViewport(0, 0, w, h);
}

void mouse_callback(GLFWwindow* window, double xposIn, double yposIn)
{
	float xpos = static_cast<float>(xposIn);
	float ypos = static_cast<float>(yposIn);

	if (firstMouse)
	{
		lastX = xpos;
		lastY = ypos;
		firstMouse = false;
	}

	float xoffset = xpos - lastX;
	float yoffset = lastY - ypos; // reversed since y-coordinates go from bottom to top

	lastX = xpos;
	lastY = ypos;

	camera.ProcessMouseMovement(xoffset, yoffset);
}

// key callback
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	// close window
	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	// toggle light
	if (key == GLFW_KEY_L && action == GLFW_PRESS)
		isOpenLight = !isOpenLight;
}


GLFWwindow* CreateWindow(int w, int h, const char* title)
{
	//Initialize the library, allocate resources
	glfwInit();

	//Specify minimum OpenGL version required to run this program (Major = 3, Minor = 3, i.e., Version 3.3)
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);

	// MSAA
	glfwWindowHint(GLFW_SAMPLES, 4);

	// enable vsync
	glfwWindowHint(GLFW_DOUBLEBUFFER, GLFW_TRUE);
	glfwSwapInterval(1);

	//Use core profile (i.e., a subset of OpenGL features without backwards-compatible features we no longer need
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	//Create a window with specified width, height, and title
	GLFWwindow* window = glfwCreateWindow(w, h, title, NULL, NULL);

	// capture cursor
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	//Make the window our current context
	glfwMakeContextCurrent(window);

	//Specify the name of the callback function when an event on the window is detected
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
	glfwSetCursorPosCallback(window, mouse_callback);
	glfwSetKeyCallback(window, key_callback);

	//Return the reference to the window object
	return window;
}
