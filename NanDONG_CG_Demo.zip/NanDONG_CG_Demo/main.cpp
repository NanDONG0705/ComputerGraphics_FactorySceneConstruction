#include <glad/glad.h> 
#include <GLFW/glfw3.h>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <iostream>

#include "window.h"

// timing
float deltaTime = 0.1f;	// time between current frame and last frame
float lastFrame = 0.0f;

const glm::vec3 pointLightPos{ -3.12f, 6.94f, 7.78f };
const glm::vec3 pointLightColor{ 1.0f,0.7117f,0.2567f };

const glm::vec3 spotLightPos{ 5.68f, 7.19f, 6.52f };
const glm::vec3 spotLightColor{ 0.0063f, 1.0f, 0.0f };
const glm::vec3 spotLightDir{ 0.0f, -1.0f, 0.0f };
const float cutoff = glm::cos(glm::radians(60.0f));


void processKeyboard(GLFWwindow* window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);
	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
		camera.ProcessKeyboard(FORWARD, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
		camera.ProcessKeyboard(BACKWARD, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
		camera.ProcessKeyboard(LEFT, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
		camera.ProcessKeyboard(RIGHT, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
		camera.ProcessKeyboard(UP, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
		camera.ProcessKeyboard(DOWN, deltaTime);
}

void processForwardBackInput(GLFWwindow* window, ModelGPU& model, float deltaTime) {
	float distance = 0.0f;

	if (glfwGetKey(window, GLFW_KEY_UP) == GLFW_PRESS) {
		distance = -1.0f * deltaTime;
	}
	else if (glfwGetKey(window, GLFW_KEY_DOWN) == GLFW_PRESS) {
		distance = 1.0f * deltaTime;
	}
	if (distance != 0.0f) {
		model.modelMatrix = glm::translate(model.modelMatrix, glm::vec3(0.0f, 0.0f, distance));
	}
}


/////////////////////////////////////////////////////////////////////////////
// main function
/////////////////////////////////////////////////////////////////////////////
int main(int argc, char** argv)
{
	// Display user instructions in console window
	printf("========= Instructions =========\n");
	printf("Press WSAD to control camera.\n");
	printf("Press QE to up and down.\n");
	printf("Press 'Esc' to quit.\n\n");

	// window
	GLFWwindow* window = CreateWindow(WindowWidth, WindowHeight, "COMP3069 CG CW2");
	gladLoadGLLoader((GLADloadproc)glfwGetProcAddress);

	// forward rendering shader
	Shader forward_shader("shaders\\forward.vert", "shaders\\forward.frag");
	Shader particle_shader("shaders\\particles.vert", "shaders\\particles.frag");

	// depth test and MSAA
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_STENCIL_TEST);
	glEnable(GL_MULTISAMPLE);

	// models
	ModelGPU classroomModel = loadModelAssimp("assets\\classroom\\classroom.obj");
	classroomModel.modelMatrix = glm::scale(glm::translate(classroomModel.modelMatrix, glm::vec3(0.0f, 2.04f, 6.9f)), glm::vec3(2.0f, 2.0f, 2.0f));

	ModelGPU trolleyModel = loadModelAssimp("assets\\trolley\\trolley.obj");
	trolleyModel.modelMatrix = glm::scale(glm::translate(trolleyModel.modelMatrix, glm::vec3(1.0f, 2.7f, 13.36f)), glm::vec3(2.0f, 2.0f, 2.0f));

	ModelGPU controlBoxModel = loadModelAssimp("assets\\control-box\\control_box.obj");
	controlBoxModel.modelMatrix = glm::scale(glm::translate(controlBoxModel.modelMatrix, glm::vec3(0.0f, 0.03f, 0.0f)), glm::vec3(0.03f, 0.03f, 0.03f));

	ModelGPU furnitureModel = loadModelAssimp("assets\\furniture\\furniture.obj");
	furnitureModel.modelMatrix = glm::scale(glm::translate(furnitureModel.modelMatrix, glm::vec3(0.0f, 0.0f, 0.0f)), glm::vec3(0.03f, 0.03f, 0.03f));

	ModelGPU pumpModel = loadModelAssimp("assets\\pump\\pump.obj");
	pumpModel.modelMatrix = glm::scale(glm::translate(pumpModel.modelMatrix, glm::vec3(0.0f, 0.0f, 0.0f)), glm::vec3(0.03f, 0.03f, 0.03f));


	ParticleState particleState;

	while (!glfwWindowShouldClose(window))
	{
		float currentFrame = static_cast<float>(glfwGetTime());
		deltaTime = currentFrame - lastFrame;
		lastFrame = currentFrame;
		// Process user input
		processKeyboard(window);

		// render
		glClearColor(0.8f, 0.8f, 0.8f, 1.f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
		//std::cout << camera.Position.x << " " << camera.Position.y << " " << camera.Position.z << std::endl;
		forward_shader.use();

		// light
		forward_shader.setVec3("pointLight.color", pointLightColor);
		forward_shader.setVec3("pointLight.position", pointLightPos);

		forward_shader.setVec3("spotLight.color", spotLightColor);
		forward_shader.setVec3("spotLight.position", spotLightPos);
		forward_shader.setVec3("spotLight.direction", spotLightDir);
		forward_shader.setFloat("spotLight.cutoff", cutoff);

		forward_shader.setBool("isOpenLight", isOpenLight);

		// transformation
		glm::mat4 view = camera.GetViewMatrix();
		glm::mat4 projection = glm::perspective(camera.Zoom, (float)WindowWidth / (float)WindowHeight, 0.1f, 100.0f);
		forward_shader.setMat4("viewProjection", projection * view);
		forward_shader.setVec3("viewPos", camera.Position);

		drawModel(classroomModel, forward_shader);

		drawModel(trolleyModel, forward_shader);
		processForwardBackInput(window, trolleyModel, deltaTime);

		drawModel(controlBoxModel, forward_shader);
		drawModel(furnitureModel, forward_shader);
		drawModel(pumpModel, forward_shader);

		particle_shader.use();
		particle_shader.setMat4("viewProjection", projection * view);
		particle_shader.setVec3("CameraRight_worldspace", camera.Right);
		particle_shader.setVec3("CameraUp_worldspace", camera.Up);

		particleState.updateParticle(deltaTime, camera);
		particleState.drawParticles(particle_shader);

		// Swap buffers and poll IO events
		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	// free data
	freeUpData(classroomModel);
	freeUpData(trolleyModel);
	freeUpData(controlBoxModel);
	freeUpData(furnitureModel);
	freeUpData(pumpModel);

	glfwTerminate();

	return 0;
}

