#pragma once

#define STB_IMAGE_IMPLEMENTATION
#include <stb_image.h>

#define GLM_ENABLE_EXPERIMENTAL
#include <glm/gtx/hash.hpp>
#include <glm/glm.hpp>
#include <glm/gtx/norm.hpp>

#include <glad/glad.h>

#include <filesystem>
#include <unordered_map>
#include <vector>

#include "shader.h"

#include <assimp/Importer.hpp>
#include <assimp/scene.h>
#include <assimp/postprocess.h>

using opengl_bind_id_t = GLuint;

struct Material
{
	opengl_bind_id_t baseColorTex{ 0 };
	glm::vec3 baseColor{ 1.0f };

	opengl_bind_id_t roughnessTex{ 0 };
	float roughness{ 0.0f };

	opengl_bind_id_t metallicTex{ 0 };
	float metallic{ 0.0f };
};

struct MeshGPU
{
	opengl_bind_id_t vao;
	opengl_bind_id_t positionsVbo;
	opengl_bind_id_t normalsVbo;
	opengl_bind_id_t texCoordsVbo;

	opengl_bind_id_t indicesEbo;

	opengl_bind_id_t materialIndex;
	opengl_bind_id_t numIndices;
};

struct ModelGPU
{
	std::vector<MeshGPU> meshes;
	std::vector<Material> materials;
	glm::mat4 modelMatrix{ glm::mat4{1.0f} };
};

struct Particle
{
	glm::vec3 pos, speed;
	glm::vec3 color; // Color
	float size, angle, weight;
	float life; // Remaining life of the particle. if <0 : dead and unused.
	float cameradistance; // *Squared* distance to the camera. if dead : -1.0f
};

struct ParticleState {
	opengl_bind_id_t vao;

	opengl_bind_id_t particlesVertexBufferData;
	opengl_bind_id_t particlesPositionBuffer;

	std::vector<float> g_particule_position_size_data;

	const int MaxParticles = 1000;
	std::vector<Particle> ParticlesContainer;
	int LastUsedParticle{ 0 };

	// The VBO containing the 4 vertices of the particles.
	// Thanks to instancing, they will be shared by all particles.
	static inline const GLfloat g_vertex_buffer_data[] = {
		-0.5f, -0.5f, 0.0f, 0.5f, -0.5f, 0.0f,
		-0.5f, 0.5f,  0.0f, 0.5f, 0.5f,  0.0f,
	};

	ParticleState() {
		ParticlesContainer.resize(MaxParticles, Particle{});
		g_particule_position_size_data.resize(MaxParticles * 4, 0.0f);

		for (auto& particle : ParticlesContainer) {
			particle.life = -1.0f;
			particle.cameradistance = -1.0f;
		}

		glGenVertexArrays(1, &vao);
		glBindVertexArray(vao);

		glGenBuffers(1, &particlesVertexBufferData);
		glBindBuffer(GL_ARRAY_BUFFER, particlesVertexBufferData);
		glBufferData(GL_ARRAY_BUFFER, sizeof(g_vertex_buffer_data),
			g_vertex_buffer_data, GL_STATIC_DRAW);

		glGenBuffers(1, &particlesPositionBuffer);
		glBindBuffer(GL_ARRAY_BUFFER, particlesPositionBuffer);
		// Initialize with empty (NULL) buffer : it will be updated later, each frame.
		glBufferData(GL_ARRAY_BUFFER, MaxParticles * 4 * sizeof(GLfloat), NULL,
			GL_STREAM_DRAW);
	}

	// Finds a Particle in ParticlesContainer which isn't used yet.
	// (i.e. life < 0);
	int FindUnusedParticle() {
		for (int i = LastUsedParticle; i < MaxParticles; i++) {
			if (ParticlesContainer[i].life < 0) {
				LastUsedParticle = i;
				return i;
			}
		}

		for (int i = 0; i < LastUsedParticle; i++) {
			if (ParticlesContainer[i].life < 0) {
				LastUsedParticle = i;
				return i;
			}
		}

		return 0; // All particles are taken, override the first one
	}

	int ParticlesCount = 0;
	void updateParticle(float deltaTime, Camera& camera) {
		// Generate 10 new particule each millisecond,
		// but limit this to 16 ms (60 fps), or if you have 1 long frame (1sec),
		// newparticles will be huge and the next frame even longer.
		int newparticles = (int)(deltaTime * 10000.0);
		if (newparticles > (int)(0.016f * 10000.0))
			newparticles = (int)(0.016f * 10000.0);

		for (int i = 0; i < newparticles; i++) {
			int particleIndex = FindUnusedParticle();
			ParticlesContainer[particleIndex].life = 5.0f; // This particle will live 5 seconds.
			ParticlesContainer[particleIndex].pos = glm::vec3(4.62f, 5.95f, 1.56f);

			float spread = 1.5f;
			glm::vec3 maindir = glm::vec3(0.0f, 10.0f, 0.0f);
			// Very bad way to generate a random direction;
			// See for instance
			// http://stackoverflow.com/questions/5408276/python-uniform-spherical-distribution
			// instead, combined with some user-controlled parameters (main direction,
			// spread, etc)
			glm::vec3 randomdir = glm::vec3((rand() % 2000 - 1000.0f) / 1000.0f,
				(rand() % 2000 - 1000.0f) / 1000.0f,
				(rand() % 2000 - 1000.0f) / 1000.0f);

			ParticlesContainer[particleIndex].speed = maindir + randomdir * spread;

			// Very bad way to generate a random color
			ParticlesContainer[particleIndex].size = (rand() % 100) / 2000.0f + 0.1f;
		}

		// Simulate all particles
		ParticlesCount = 0;
		for (int i = 0; i < MaxParticles; i++) {

			Particle& p = ParticlesContainer[i]; // shortcut

			if (p.life > 0.0f) {

				// Decrease life
				p.life -= deltaTime;
				if (p.life > 0.0f) {

					// Simulate simple physics : gravity only, no collisions
					p.speed += glm::vec3(0.0f, -40.0f, 0.0f) * (float)deltaTime * 0.5f;
					p.pos += p.speed * (float)deltaTime;
					p.cameradistance = glm::length2(p.pos - camera.Position);
					// ParticlesContainer[i].pos += glm::vec3(0.0f,10.0f, 0.0f) *
					// (float)delta;

					// Fill the GPU buffer
					g_particule_position_size_data[4 * ParticlesCount + 0] = p.pos.x;
					g_particule_position_size_data[4 * ParticlesCount + 1] = p.pos.y;
					g_particule_position_size_data[4 * ParticlesCount + 2] = p.pos.z;

					g_particule_position_size_data[4 * ParticlesCount + 3] = p.size;
				}
				else {
					// Particles that just died will be put at the end of the buffer in
					// SortParticles();
					p.cameradistance = -1.0f;
				}

				ParticlesCount++;
			}
		}

		// Update the buffers that OpenGL uses for rendering.
		// There are much more sophisticated means to stream data from the CPU to
		// the GPU, but this is outside the scope of this tutorial.
		// http://www.opengl.org/wiki/Buffer_Object_Streaming

		glBindBuffer(GL_ARRAY_BUFFER, particlesPositionBuffer);
		glBufferData(GL_ARRAY_BUFFER, MaxParticles * 4 * sizeof(GLfloat), NULL,
			GL_STREAM_DRAW); // Buffer orphaning, a common way to improve
		// streaming perf. See above link for details.
		glBufferSubData(GL_ARRAY_BUFFER, 0, ParticlesCount * sizeof(GLfloat) * 4,
			g_particule_position_size_data.data());
	}

	void drawParticles(Shader& shader) {
		glBindVertexArray(vao);

		// 1rst attribute buffer : vertices
		glEnableVertexAttribArray(0);
		glBindBuffer(GL_ARRAY_BUFFER, particlesVertexBufferData);
		glVertexAttribPointer(0, // attribute. No particular reason for 0, but must
			// match the layout in the shader.
			3, // size
			GL_FLOAT, // type
			GL_FALSE, // normalized?
			0,        // stride
			(void*)0 // array buffer offset
		);

		// 2nd attribute buffer : positions of particles' centers
		glEnableVertexAttribArray(1);
		glBindBuffer(GL_ARRAY_BUFFER, particlesPositionBuffer);
		glVertexAttribPointer(1, // attribute. No particular reason for 1, but must
			// match the layout in the shader.
			4, // size : x + y + z + size => 4
			GL_FLOAT, // type
			GL_FALSE, // normalized?
			0,        // stride
			(void*)0 // array buffer offset
		);

		// These functions are specific to glDrawArrays*Instanced*.
		// The first parameter is the attribute buffer we're talking about.
		// The second parameter is the "rate at which generic vertex attributes
		// advance when rendering multiple instances"
		// http://www.opengl.org/sdk/docs/man/xhtml/glVertexAttribDivisor.xml
		glVertexAttribDivisor(
			0, 0); // particles vertices : always reuse the same 4 vertices -> 0
		glVertexAttribDivisor(1, 1); // positions : one per quad (its center) -> 1

		// Draw the particules !
		// This draws many times a small triangle_strip (which looks like a quad).
		// This is equivalent to :
		// for(i in ParticlesCount) : glDrawArrays(GL_TRIANGLE_STRIP, 0, 4),
		// but faster.
		glDrawArraysInstanced(GL_TRIANGLE_STRIP, 0, 4, ParticlesCount);
	}

};

opengl_bind_id_t loadTexture2D(std::filesystem::path const& path, bool SRGB = true) {
	int width, height, channels;

	// flip
	stbi_set_flip_vertically_on_load(true);
	stbi_uc* data = stbi_load(path.generic_string().c_str(), &width, &height, &channels, STBI_rgb_alpha);

	if (!data) {
		throw std::runtime_error("Failed to load texture: " + path.generic_string());
	}

	opengl_bind_id_t texture;
	glGenTextures(1, &texture);
	glBindTexture(GL_TEXTURE_2D, texture);

	if (SRGB) {
		glTexImage2D(GL_TEXTURE_2D, 0, GL_SRGB_ALPHA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
	}
	else {
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
	}
	glGenerateMipmap(GL_TEXTURE_2D);

	stbi_image_free(data);

	return texture;
}

MeshGPU processMesh(aiMesh* mesh, const aiScene* scene)
{
	// data to fill
	std::vector<glm::vec3> positions;
	std::vector<glm::vec3> normals;
	std::vector<glm::vec2> texCoords;

	std::vector<opengl_bind_id_t> indices;

	MeshGPU meshGPU;

	// walk through each of the mesh's vertices
	for (unsigned int i = 0; i < mesh->mNumVertices; i++)
	{
		glm::vec3 vector; // we declare a placeholder vector since assimp uses its own vector class that doesn't directly convert to glm's vec3 class so we transfer the data to this placeholder glm::vec3 first.
		// positions
		vector.x = mesh->mVertices[i].x;
		vector.y = mesh->mVertices[i].y;
		vector.z = mesh->mVertices[i].z;
		positions.push_back(vector);

		// normals
		if (mesh->HasNormals())
		{
			vector.x = mesh->mNormals[i].x;
			vector.y = mesh->mNormals[i].y;
			vector.z = mesh->mNormals[i].z;
			normals.push_back(vector);
		}
		// texture coordinates
		if (mesh->mTextureCoords[0]) // does the mesh contain texture coordinates?
		{
			glm::vec2 vec;
			// a vertex can contain up to 8 different texture coordinates. We thus make the assumption that we won't 
			// use models where a vertex can have multiple texture coordinates so we always take the first set (0).
			vec.x = mesh->mTextureCoords[0][i].x;
			vec.y = mesh->mTextureCoords[0][i].y;

			texCoords.push_back(vec);
		}
		else
			texCoords.push_back(glm::vec2(0.0f, 0.0f));
	}
	// now wak through each of the mesh's faces (a face is a mesh its triangle) and retrieve the corresponding vertex indices.
	for (unsigned int i = 0; i < mesh->mNumFaces; i++)
	{
		aiFace face = mesh->mFaces[i];
		// retrieve all indices of the face and store them in the indices vector
		for (unsigned int j = 0; j < face.mNumIndices; j++)
			indices.push_back(face.mIndices[j]);
	}

	meshGPU.numIndices = indices.size();
	meshGPU.materialIndex = mesh->mMaterialIndex;

	// transfer to GPU
	glGenVertexArrays(1, &meshGPU.vao);
	glBindVertexArray(meshGPU.vao);

	glGenBuffers(1, &meshGPU.positionsVbo);
	glBindBuffer(GL_ARRAY_BUFFER, meshGPU.positionsVbo);
	glBufferData(GL_ARRAY_BUFFER, positions.size() * sizeof(glm::vec3), positions.data(), GL_STATIC_DRAW);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, nullptr);

	glGenBuffers(1, &meshGPU.texCoordsVbo);
	glBindBuffer(GL_ARRAY_BUFFER, meshGPU.texCoordsVbo);
	glBufferData(GL_ARRAY_BUFFER, texCoords.size() * sizeof(glm::vec2), texCoords.data(), GL_STATIC_DRAW);
	glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 0, nullptr);

	glGenBuffers(1, &meshGPU.normalsVbo);
	glBindBuffer(GL_ARRAY_BUFFER, meshGPU.normalsVbo);
	glBufferData(GL_ARRAY_BUFFER, normals.size() * sizeof(glm::vec3), normals.data(), GL_STATIC_DRAW);
	glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 0, nullptr);

	glEnableVertexAttribArray(0);
	glEnableVertexAttribArray(1);
	glEnableVertexAttribArray(2);

	glGenBuffers(1, &meshGPU.indicesEbo);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, meshGPU.indicesEbo);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(opengl_bind_id_t), indices.data(), GL_STATIC_DRAW);

	glBindVertexArray(0);

	// return a mesh object created from the extracted mesh data
	return meshGPU;
}

void processMaterials(ModelGPU& model, const aiScene* scene, std::filesystem::path const& directory) {

	for (int i = 0; i < scene->mNumMaterials; i++) {
		Material material;

		aiMaterial* mat = scene->mMaterials[i];

		aiColor3D color;
		mat->Get(AI_MATKEY_COLOR_DIFFUSE, color);
		material.baseColor = glm::vec3(color.r, color.g, color.b);

		mat->Get(AI_MATKEY_ROUGHNESS_FACTOR, material.roughness);
		mat->Get(AI_MATKEY_METALLIC_FACTOR, material.metallic);

		// check for textures
		aiString str;
		if (mat->GetTexture(aiTextureType_DIFFUSE, 0, &str) == AI_SUCCESS) {
			material.baseColorTex = loadTexture2D(directory / str.C_Str());
		}

		if (mat->GetTexture(aiTextureType_SPECULAR, 0, &str) == AI_SUCCESS) {
			material.metallicTex = loadTexture2D(directory / str.C_Str(), false);
		}

		if (mat->GetTexture(aiTextureType_HEIGHT, 0, &str) == AI_SUCCESS) {
			material.roughnessTex = loadTexture2D(directory / str.C_Str(), false);
		}

		model.materials.push_back(material);
	}
}

// processes a node in a recursive fashion. Processes each individual mesh located at the node and repeats this process on its children nodes (if any).
void processNode(ModelGPU& model, aiNode* node, const aiScene* scene)
{
	// process each mesh located at the current node
	for (unsigned int i = 0; i < node->mNumMeshes; i++)
	{
		// the node object only contains indices to index the actual objects in the scene. 
		// the scene contains all the data, node is just to keep stuff organized (like relations between nodes).
		aiMesh* mesh = scene->mMeshes[node->mMeshes[i]];
		model.meshes.push_back(processMesh(mesh, scene));
	}
	// after we've processed all of the meshes (if any) we then recursively process each of the children nodes
	for (unsigned int i = 0; i < node->mNumChildren; i++)
	{
		processNode(model, node->mChildren[i], scene);
	}

}

inline ModelGPU loadModelAssimp(std::filesystem::path const& path) {
	ModelGPU model;

	// read file via ASSIMP
	Assimp::Importer importer;
	const aiScene* scene = importer.ReadFile(path.generic_string(), aiProcess_Triangulate | aiProcess_GenSmoothNormals | aiProcess_FlipUVs | aiProcess_CalcTangentSpace);
	// check for errors
	if (!scene || scene->mFlags & AI_SCENE_FLAGS_INCOMPLETE || !scene->mRootNode) // if is Not Zero
	{
		std::cout << "ERROR::ASSIMP:: " << importer.GetErrorString() << std::endl;
		return model;
	}
	// retrieve the directory path of the filepath
	std::filesystem::path directory = path.parent_path();

	processMaterials(model, scene, directory);

	// process ASSIMP's root node recursively
	processNode(model, scene->mRootNode, scene);

	return model;
}

void drawModel(ModelGPU const& model, Shader& shader) {
	shader.setMat4("model", model.modelMatrix);
	shader.setMat3("normMat33", glm::mat3(glm::transpose(glm::inverse(model.modelMatrix))));

	for (auto& mesh : model.meshes) {
		if (model.materials[mesh.materialIndex].baseColorTex == 0) {
			shader.setBool("useBaseColorTex", false);
			shader.setVec3("baseColorVec", model.materials[mesh.materialIndex].baseColor);
		}
		else {
			shader.setBool("useBaseColorTex", true);
			glActiveTexture(GL_TEXTURE0);
			glBindTexture(GL_TEXTURE_2D, model.materials[mesh.materialIndex].baseColorTex);
		}

		if (model.materials[mesh.materialIndex].roughnessTex == 0) {
			shader.setFloat("roughness", model.materials[mesh.materialIndex].roughness);
			shader.setBool("useRoughnessTex", false);
		}
		else {
			glActiveTexture(GL_TEXTURE1);
			glBindTexture(GL_TEXTURE_2D, model.materials[mesh.materialIndex].roughnessTex);
			shader.setFloat("roughness", 1.0f);
			shader.setBool("useRoughnessTex", true);
		}

		if (model.materials[mesh.materialIndex].metallicTex == 0) {
			shader.setFloat("metallic", model.materials[mesh.materialIndex].metallic);
			shader.setBool("useMetallicTex", false);
		}
		else {
			glActiveTexture(GL_TEXTURE2);
			glBindTexture(GL_TEXTURE_2D, model.materials[mesh.materialIndex].metallicTex);
			shader.setFloat("metallic", 1.0f);
			shader.setBool("useMetallicTex", true);
		}

		glBindVertexArray(mesh.vao);
		glDrawElements(GL_TRIANGLES, mesh.numIndices, GL_UNSIGNED_INT, nullptr);
	}
}

void freeUpData(ModelGPU& model) {
	for (int i = 0; i < model.materials.size(); i++) {
		Material& mat = model.materials[i];

		glDeleteTextures(1, &mat.metallicTex);
		glDeleteTextures(1, &mat.baseColorTex);
		glDeleteTextures(1, &mat.roughnessTex);
	}

	for (int i = 0; i < model.meshes.size(); i++) {
		MeshGPU& mesh = model.meshes[i];

		glDeleteVertexArrays(1, &mesh.vao);
		glDeleteBuffers(1, &mesh.texCoordsVbo);
		glDeleteBuffers(1, &mesh.normalsVbo);
		glDeleteBuffers(1, &mesh.indicesEbo);
		glDeleteBuffers(1, &mesh.positionsVbo);
	}
}
